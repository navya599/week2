var name_array1=["navya", "steffi", "sony"];
var place_array=["wgl","hyd","uppal"];
document.write('<table border="1" cellspacing="0" cellpadding="5"><tr><th>Name</th><th>place</th>')
for(var i=0; i < name_array1.length;i++){
    document.write("<tr><td>"+name_array1[i]+"</td><td>"+place_array[i]+"</td></tr>")

}
document.write("</table>")