var input = prompt(" enter your alphabet A to D : ");
var grade = '';
switch (input) {
    case 'A':
        grade = "Excellcent";
        alert(grade);
        break;
    case 'B':
        grade = "Good";
        alert(grade);
        break;
    case 'C':
        grade = "Fair";
        alert(grade);
        break;
    case 'D':
        grade = "Poor";
        alert(grade);
        break;
    default: {
        alert("Invailid Entry");
        break;
    }
}
